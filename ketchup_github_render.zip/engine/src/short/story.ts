// "Before Alarm Clocks, People Paid Someone to Wake Them Up" - the story timeline: one entry per camera angle (Knackery
// pacing: a new angle on almost every phrase). Frame = 1/30 s of the cleaned Loyal voiceover (knock-short/voice/clean.wav,
// 48.95 s, padded to 49.2 s). The film LOOPS by its words: it ends on "...just remember:" and the restart answers it:
// "Two hundred years ago, most workers couldn't afford an alarm clock."
export const FPS = 30;
export const TOTAL = 1542;
export type V3 = [number, number, number];

export const clamp01 = (x: number) => Math.max(0, Math.min(1, x));
export const smooth = (x: number) => { const u = clamp01(x); return u * u * (3 - 2 * u); };
export const easeOut = (u: number) => 1 - (1 - clamp01(u)) ** 3;
export const lerp = (a: number, b: number, k: number) => a + (b - a) * k;
const T = (f: number) => f / FPS;
const fr = (s: number) => Math.round(s * FPS);
/** 0 before a, 1 after b, smooth in between */
export const ramp = (t: number, a: number, b: number) => smooth((t - a) / (b - a));

// ---------------- sets (each its own patch of the one world, far apart) ----------------
export type SetName = "shop" | "street" | "bed" | "gate" | "london" | "attic" | "seventies" | "modern";
export const ORG: Record<SetName, V3> = {
  shop: [0, 0, 0], street: [3000, 0, 0], bed: [6000, 0, 0], gate: [9000, 0, 0], london: [12000, 0, 0], attic: [15000, 0, 0], seventies: [18000, 0, 0], modern: [21000, 0, 0],
};
export const INDOOR: Record<SetName, boolean> = { shop: false, street: false, bed: true, gate: false, london: false, attic: true, seventies: false, modern: true };
export const at = (s: SetName, x: number, y: number, z: number): V3 => [ORG[s][0] + x, ORG[s][1] + y, ORG[s][2] + z];

export type Light = "day" | "golden" | "night" | "indoor" | "dim";
export type ShotDef = { id: number; a: number; b: number; set: SetName; light: Light; name: string; sunAz?: number; sunEl?: number; fog?: [number, number] };
// [start s (a word onset), set, light, name]
const PLAN: [number, SetName, Light, string][] = [
  [0.0, "shop", "golden", "in 1834 ketchup wasn't a sauce (loop frame)"],
  [2.7, "shop", "golden", "it was medicine"],
  [3.44, "street", "golden", "many Americans thought tomatoes were poisonous"],
  [4.99, "street", "golden", "tomatoes were poisonous (close)"],
  [6.39, "street", "golden", "an Ohio doctor named John Cook Bennett walks in"],
  [8.29, "street", "golden", "changed everything"],
  [9.59, "street", "golden", "he announced tomatoes could cure"],
  [11.12, "bed", "indoor", "diarrhea indigestion jaundice"],
  [13.52, "shop", "day", "he published ketchup recipes"],
  [15.5, "shop", "day", "squeezed into pills"],
  [17.5, "gate", "golden", "a salesman named Archibald Miles"],
  [19.3, "gate", "golden", "sold them as Dr Miles Compound Extract of Tomato"],
  [22.35, "gate", "golden", "they were a hit"],
  [22.99, "london", "day", "copycats everywhere"],
  [26.03, "london", "day", "ads sang"],
  [26.73, "london", "day", "tomato pills will cure all your ills"],
  [28.8, "shop", "day", "some pills had no tomato"],
  [30.79, "shop", "day", "a few were just laxatives"],
  [32.22, "street", "day", "doctors started asking questions"],
  [33.8, "street", "day", "the craze fell apart"],
  [34.86, "seventies", "day", "people learned to love tomatoes"],
  [37.01, "seventies", "day", "by 1876 Heinz"],
  [38.91, "seventies", "day", "selling tomato ketchup as a sauce"],
  [40.93, "seventies", "day", "no pills required"],
  [42.01, "street", "golden", "and that's the plot twist"],
  [43.4, "street", "golden", "ketchup was once fake medicine"],
  [45.47, "street", "golden", "and became real food"],
  [46.98, "street", "golden", "next time you squeeze ketchup on your fries"],
  [49.17, "street", "golden", "just remember: in 1834"],
];
export const SHOTS: ShotDef[] = PLAN.map(([s, set, light, name], i) => ({
  id: i + 1, a: fr(s), b: i + 1 < PLAN.length ? fr(PLAN[i + 1][0]) : TOTAL, set, light, name,
  // golden shots: the low sun from behind the lens lights the facades warm (instead of backlighting them)
  ...(light === "golden" ? { sunAz: set === "street" ? 125 : 155, sunEl: 14 } : {}),
}));
export const XFADE: Record<number, number> = Object.fromEntries(SHOTS.map((s) => [s.id, 0]));
export const DIS = 6;
export const FLASH_AT = -100;

export const shotAt = (f: number) => SHOTS.find((s) => f >= s.a && f < s.b) ?? SHOTS[SHOTS.length - 1];
export type Layer = { id: number; alpha: number; v: number };
export const layersAt = (f: number): Layer[] => [{ id: shotAt(f).id, alpha: 1, v: 0 }];

// ---------------- layouts (local coords; world.ts, cast.ts and the cameras share these) ----------------
/** the terraced streets (street / london / seventies): front facades at z FZ, pavement up to the curb at z CZ (height PH),
 *  the hero house's upstairs bedroom window centred at (WX, WY) with its glass at z WZ */
export const FZ = -6.0, CZ = -4.4, PH = 0.15, WX = 1.0, WY = 4.1, WZ = -6.06, WW = 1.0, WH = 1.25;
/** where the knocker-upper stands to reach the hero window (on the pavement) */
export const KU: V3 = [2.05, PH, -4.65];
/** Mary Smith in the London street (on the road) */
export const MARY: V3 = [2.4, 0, -2.9];
/** the shop: glass at z SGZ, the hero alarm clock on its stand */
export const SGZ = -3.62, CLOCK: V3 = [0.0, 1.32, -3.9];
/** the bedrooms (bed, attic, modern): bed along x, head end at x BX0; mattress top BY */
export const BY = 0.56, BZ = -1.85, BX0 = -2.12, BX1 = 0.32;
/** the sleeper's head on the pillow (centre) */
export const HEADX = -1.45, HEADY = BY + 0.47;
export const WIN_B: V3 = [-0.55, 1.75, -2.37]; // bedroom window centre (glass) in the bed set
/** the mill gate: facade z GTZ, gate half-width GW */
export const GTZ = -8.0, GW = 2.0;

export const P = {
  worker: [0.95, PH, -2.55] as V3,
  foreman: [-1.25, 0, -7.3] as V3, late: [0.9, 0, -6.5] as V3,
};

// ---------------- the pole and the peas, as functions of narration time ----------------
/** tap: how far the pole tip is drawn back from the glass (0 = touching, 1 = 7 cm back); taps 2.6 a second */
export const tapAt = (t: number) => { const k = Math.sin(t * 2 * Math.PI * 2.6); return k > 0 ? k : 0; };
/** the knocker-upper's pole: "up" (tip on the hero window), "carry" (held upright as he walks), "lean" (against the wall) */
export const poleMode = (id: number): "up" | "carry" | "lean" | "none" =>
  [5, 6, 7, 8, 14, 15, 16, 17, 25, 26, 27, 28, 32, 33].includes(id) ? "up" : [4, 13, 31].includes(id) ? "carry" : id === 29 ? "lean" : "none";

// ---------------- camera ----------------
export type Cam = { pos: V3; look: V3; fov: number; roll: number };
type Shot = Partial<Cam> & { pos: V3; look: V3 };
type Key = { f: number; dur?: number; cut?: boolean; s: (f: number) => Shot };
export const glide = (u: number) => { const x = clamp01(u); return x * x * x * (x * (6 * x - 15) + 10); };
const mixC = (a: Cam, b: Cam, k: number): Cam => ({
  pos: a.pos.map((v, i) => v + (b.pos[i] - v) * k) as V3, look: a.look.map((v, i) => v + (b.look[i] - v) * k) as V3,
  fov: a.fov + (b.fov - a.fov) * k, roll: a.roll + (b.roll - a.roll) * k,
});
const full = (c: Shot): Cam => ({ fov: 40, roll: 0, ...c });
const run = (keys: Key[], f: number) => {
  let cur = full(keys[0].s(f));
  for (let i = 1; i < keys.length; i++) {
    const k = keys[i];
    if (f < k.f) break;
    cur = k.cut ? full(k.s(f)) : mixC(cur, full(k.s(f)), glide((f - k.f) / (k.dur ?? 24)));
  }
  return cur;
};
const pushK = (f: number, f0: number, rate: number) => Math.exp(-rate * Math.max(0, f - f0));
const dolly = (pos: V3, look: V3, k: number, rest: Partial<Cam> = {}): Shot =>
  ({ pos: [look[0] + (pos[0] - look[0]) * k, look[1] + (pos[1] - look[1]) * k, look[2] + (pos[2] - look[2]) * k], look, ...rest });
type CuOpt = { fov?: number; roll?: number; rate?: number };
/** orbit framing around a set-local look point: d metres away, az degrees (0 = camera on the +z side, + = to the right), dy above it */
const cu = (s: SetName, look: V3, d: number, az: number, dy: number, f0: number, o: CuOpt = {}) => (f: number): Shot => {
  const L = at(s, look[0], look[1], look[2]), a = (az * Math.PI) / 180;
  return dolly([L[0] + d * Math.sin(a), L[1] + dy, L[2] + d * Math.cos(a)], L, pushK(f, f0, o.rate ?? 0.003), { fov: o.fov ?? 36, roll: o.roll ?? 0 });
};
/** a straight track from pos0/look0 to pos1/look1 over n frames (smooth) */
const track = (s: SetName, p0: V3, l0: V3, p1: V3, l1: V3, f0: number, n: number, fov = 40, roll = 0) => (f: number): Shot => {
  const u = smooth((f - f0) / n), L = (a: V3, b: V3): V3 => at(s, lerp(a[0], b[0], u), lerp(a[1], b[1], u), lerp(a[2], b[2], u));
  return { pos: L(p0, p1), look: L(l0, l1), fov, roll };
};
const loc = (s: SetName, p: V3): V3 => at(s, p[0], p[1], p[2]);
/** head centre above the feet (standing card) */
const H = 1.42;
const head = (p: V3, dy = 0): V3 => [p[0], p[1] + H + dy, p[2]];
const S0 = (id: number) => SHOTS[id - 1].a;
const N = (id: number) => SHOTS[id - 1].b - SHOTS[id - 1].a;
const add = (a: V3, b: V3): V3 => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const WIN: V3 = [WX, WY, WZ];

/** where the walking knocker-upper is in shots 4, 13 and 31 (x along the pavement) */
export const walkX = (id: number, t: number) => id === 4 ? lerp(-3.4, KU[0], ramp(t, 5.62, 6.7)) : id === 13 ? lerp(-5.5, -1.5, (t - 16.62) / 3.1)
  : id === 31 ? lerp(KU[0], 4.6, (t - 41.5) / 1.02) : KU[0];

export const BEN: V3 = [-1.2, PH, -5.2];
export const GP: V3 = [1.4, PH, -4.7];
export const MILES: V3 = [-0.2, 0, -7.0];
export const D1: V3 = [0.7, PH, -4.9], D2: V3 = [1.8, PH, -4.9];
const CAMS: Record<number, Key[]> = {
  1: [{ f: 0, s: (f) => dolly(loc("shop", [3.2, 1.75, 2.6]), loc("shop", [0.15, 1.35, -3.4]), pushK(f, 0, 0.0035), { fov: 44 }) }],
  2: [{ f: S0(2), s: cu("shop", add(CLOCK, [0.32, -0.05, 0.7]), 1.6, 14, 0.1, S0(2), { fov: 36, rate: 0.004 }) }],
  3: [{ f: S0(3), s: (f) => dolly(loc("street", [2.6, 2.0, 5.2]), loc("street", [1.2, 2.0, -5.4]), pushK(f, S0(3), 0.003), { fov: 50 }) }],
  4: [{ f: S0(4), s: cu("street", [1.2, 0.85, -4.7], 2.6, 10, 0.25, S0(4), { fov: 36, rate: 0.005 }) }],
  5: [{ f: S0(5), s: track("street", [-3.6, 1.5, -1.2], [-5.0, 1.45, -4.7], [0.4, 1.5, -1.2], [-1.0, 1.45, -4.7], S0(5), N(5), 42) }],
  6: [{ f: S0(6), s: cu("street", head(BEN, -0.2), 2.4, 8, 0.1, S0(6), { fov: 36, rate: 0.008 }) }],
  7: [{ f: S0(7), s: cu("street", head(BEN, -0.3), 3.3, -14, 0.1, S0(7), { fov: 38, rate: 0.004 }) }],
  8: [{ f: S0(8), s: cu("bed", [-1.25, 1.12, BZ], 2.6, 8, 0.25, S0(8), { fov: 40, rate: 0.004 }) }],
  9: [{ f: S0(9), s: cu("shop", [0.6, 1.4, -3.2], 3.3, 14, 0.15, S0(9), { fov: 40, rate: 0.004 }) }],
  10: [{ f: S0(10), s: cu("shop", [0.1, 1.45, -3.9], 2.3, 6, 0.0, S0(10), { fov: 40, rate: 0.003 }) }],
  11: [{ f: S0(11), s: cu("gate", head(MILES, -0.1), 3.3, -10, 0.1, S0(11), { fov: 38, rate: 0.004 }) }],
  12: [{ f: S0(12), s: cu("gate", [0.35, 1.5, -6.9], 6.2, 6, 0.2, S0(12), { fov: 40, rate: 0.003 }) }],
  13: [{ f: S0(13), s: (f) => dolly(loc("gate", [-5.2, 1.7, 3.2]), loc("gate", [1.2, 3.2, -8.0]), pushK(f, S0(13), 0.002), { fov: 48 }) }],
  14: [{ f: S0(14), s: cu("london", [2.4, 1.3, -2.9], 6.2, 0, 0.5, S0(14), { fov: 44, rate: 0.002 }) }],
  15: [{ f: S0(15), s: cu("london", head(MARY, -0.2), 2.6, 14, 0.05, S0(15), { fov: 36, rate: 0.005 }) }],
  16: [{ f: S0(16), s: cu("london", [2.4, 1.7, -3.6], 4.8, 10, 0.2, S0(16), { fov: 40, rate: 0.003 }) }],
  17: [{ f: S0(17), s: cu("shop", [0.9, 1.3, -2.9], 2.2, 10, 0.1, S0(17), { fov: 38, rate: 0.004 }) }],
  18: [{ f: S0(18), s: cu("shop", [2.6, 1.3, -2.8], 5.2, 4, 0.3, S0(18), { fov: 42, rate: 0.002 }) }],
  19: [{ f: S0(19), s: cu("street", [1.2, 1.5, -4.9], 4.4, 6, 0.2, S0(19), { fov: 40, rate: 0.004 }) }],
  20: [{ f: S0(20), s: cu("street", [1.2, 0.9, -4.6], 3.4, 8, 0.5, S0(20), { fov: 42, rate: 0.003 }) }],
  21: [{ f: S0(21), s: (f) => dolly(loc("seventies", [5.4, 1.6, 2.0]), loc("seventies", [1.3, 2.0, -5.2]), pushK(f, S0(21), 0.003), { fov: 46 }) }],
  22: [{ f: S0(22), s: cu("seventies", [2.05, 1.5, -4.65], 4.0, 14, 0.2, S0(22), { fov: 40, rate: 0.003 }) }],
  23: [{ f: S0(23), s: cu("seventies", [2.05, 1.7, -4.65], 3.8, -8, 0.0, S0(23), { fov: 36, rate: 0.005 }) }],
  24: [{ f: S0(24), s: cu("seventies", [2.05, 1.4, -4.65], 3.4, 6, 0.1, S0(24), { fov: 38, rate: 0.004 }) }],
  25: [{ f: S0(25), s: cu("street", head(GP, -0.2), 3.0, -12, 0.1, S0(25), { fov: 38, rate: 0.004 }) }],
  26: [{ f: S0(26), s: cu("street", [1.15, 1.35, -4.7], 4.4, 10, 0.1, S0(26), { fov: 40, rate: 0.003 }) }],
  27: [{ f: S0(27), s: cu("street", head(GP, -0.15), 2.3, 6, 0.05, S0(27), { fov: 36, rate: 0.006 }) }],
  28: [{ f: S0(28), s: cu("street", [1.4, 1.15, -4.7], 2.7, 10, 0.15, S0(28), { fov: 36, rate: 0.004 }) }],
  29: [{ f: S0(29), s: cu("street", head(GP, -0.2), 2.4, -6, 0.05, S0(29), { fov: 36, rate: 0.005 }) }],
};
// impact kicks: image offset flips sign every frame and decays over 7 f
const KICKS: [number, number][] = [[8.66, 0.6], [34.4, 0.6], [42.95, 0.5]];
export const kickAt = (t: number) => {
  let a = 0;
  for (const [t0, g] of KICKS) {
    const n = Math.floor((t - t0) * FPS + 1e-6);
    if (n >= 0 && n < 7) a += g * (n % 2 ? -1 : 1) * (1 - n / 7) ** 1.5;
  }
  return a;
};
export const camAt = (id: number, f: number, _v = 0): Cam => {
  const c = run(CAMS[id], f), a = kickAt(T(f));
  if (!a) return c;
  const d: V3 = [c.look[0] - c.pos[0], c.look[1] - c.pos[1], c.look[2] - c.pos[2]];
  const L = Math.hypot(...d), h = Math.hypot(d[0], d[2]) || 1;
  const m = (3 / 640) * Math.tan((c.fov * Math.PI) / 360) * L * a;
  return { ...c, look: [c.look[0] - (d[2] / h) * m, c.look[1] + 0.6 * m, c.look[2] + (d[0] / h) * m], roll: c.roll + a * 0.004 };
};

export const dofAt = (_f: number) => ({ cInf: 0, focus: undefined as undefined | ((f: number) => V3) });
