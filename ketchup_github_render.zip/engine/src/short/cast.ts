// Our cast as lit flat sprites in the 3D world (pool, cards, blobs and the person() drawing call come from the
// cartoon-short template); below them, who stands where in each shot of the Netflix short and what they do.
import * as THREE from "three";
import { Pen, bodyFront, bodySide, fxBurst, fxShadow, fxContact, Outfit, Expr, FrontOpts, SideOpts, SKIN, INK, Prop, ANCHOR } from "./toon";
import { FPS, TOTAL, V3, smooth, clamp01, SHOTS, at, P, SetName, KU, MARY, FZ, PH, WX, WY, WZ, WW, WH, BY, BZ, BX1, HEADX, HEADY, tapAt, walkX, ramp, lerp, BEN, MILES, D1, D2, GP } from "./story";
import { NOINK } from "./ink";
import { TRACKS, PROPS, evalTrack } from "./acting";
import { cardShade, blobMaterial, CARD_K } from "./cardshade";
// ---------------- canvas pool ----------------
type Entry = { cv: HTMLCanvasElement; tex: THREE.CanvasTexture; w: number; h: number };
export type Req = { key: string; w: number; h: number; k: number; draw: (p: Pen) => void; tex?: THREE.CanvasTexture };
const makeEntry = (w: number, h: number): Entry => {
  const cv = document.createElement("canvas");
  cv.width = w; cv.height = h;
  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 8;
  return { cv, tex, w, h };
};
export class Pool {
  private live = new Map<string, Entry>();
  private free: Entry[] = [];
  private reqs: Req[] = [];
  req(key: string, w: number, h: number, k: number, draw: (p: Pen) => void) {
    const r: Req = { key: `${w}x${h}|${key}`, w, h, k, draw };
    this.reqs.push(r);
    return r;
  }
  flush() {
    const want = new Map<string, Req[]>();
    for (const r of this.reqs) { const l = want.get(r.key); if (l) l.push(r); else want.set(r.key, [r]); }
    for (const [key, e] of this.live) if (!want.has(key)) { this.live.delete(key); this.free.push(e); }
    for (const [key, rs] of want) {
      let e = this.live.get(key);
      if (!e) {
        const r = rs[0], i = this.free.findIndex((x) => x.w === r.w && x.h === r.h);
        e = i >= 0 ? this.free.splice(i, 1)[0] : makeEntry(r.w, r.h);
        const g = e.cv.getContext("2d")!;
        g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, e.w, e.h); g.setTransform(r.k, 0, 0, r.k, 0, 0);
        r.draw(new Pen(g));
        e.tex.needsUpdate = true;
        this.live.set(key, e);
      }
      for (const r of rs) r.tex = e.tex;
    }
    this.reqs = [];
  }
}

// ---------------- sprite meshes ----------------
const blank = (() => { const c = document.createElement("canvas"); c.width = c.height = 2; return new THREE.CanvasTexture(c); })();
export const SU = 0.00216; // metres per design unit: 1000 units = 2.16 m
export const SU_SWING = 2.3 / 1830; // swing canvas: rope of 1830 units = 2.3 m
const BODY = (() => { const g = new THREE.PlaneGeometry(600 * SU, 1000 * SU); g.translate(0, (975 - 500) * SU, 0); return g; })();
const CARD = new THREE.PlaneGeometry(1, 1);
/** world roots that hold actors (to find the scene's sun when world.ts does not pass it) */
const ROOTS = new Set<THREE.Object3D>();

/** lit flat character: cardShade() material, receives shadows (dims to the bright floor only), casts its silhouette
 *  when world.ts says so (golden). Drawn after the contact blobs (renderOrder 1). */
export class Actor {
  mesh: THREE.Mesh; mat: THREE.MeshLambertMaterial; dmat: THREE.MeshDepthMaterial; r: Req | null = null;
  constructor(parent: THREE.Object3D, geo: THREE.BufferGeometry = BODY) {
    this.mat = cardShade(new THREE.MeshLambertMaterial({ map: blank, alphaTest: 0.5, side: THREE.DoubleSide }));
    this.mat.alphaToCoverage = false; // A2C + MSAA left 1 px sky-depth seams on blurred far cards (POST)
    this.dmat = new THREE.MeshDepthMaterial({ depthPacking: THREE.RGBADepthPacking, map: blank, alphaTest: 0.5, side: THREE.DoubleSide });
    this.mesh = new THREE.Mesh(geo, this.mat);
    this.mesh.customDepthMaterial = this.dmat;
    // rim width is in output pixels: tell the card shader the render height (1920 = 1080 x 1920 frame)
    this.mesh.onBeforeRender = (r) => { const rt = r.getRenderTarget(); CARD_K.uPx.value = (rt ? rt.height : r.domElement.height) / 1920; };
    this.mesh.castShadow = false; this.mesh.receiveShadow = true; this.mesh.visible = false;
    this.mesh.rotation.order = "YXZ"; this.mesh.renderOrder = 1; this.mesh.layers.set(NOINK);
    parent.add(this.mesh);
    ROOTS.add(parent);
  }
  bind() { const t = this.r?.tex; if (t) { this.mat.map = t; this.dmat.map = t; } }
}
/** unlit effect card: hard cut-out (ink drawings), soft see-through (dust, mist) or a multiply ground blob */
export class Fx {
  mesh: THREE.Mesh; mat: THREE.MeshBasicMaterial; soft: THREE.MeshBasicMaterial; blob: THREE.MeshBasicMaterial; r: Req | null = null;
  constructor(parent: THREE.Object3D) {
    this.mat = new THREE.MeshBasicMaterial({ map: blank, alphaTest: 0.5, side: THREE.DoubleSide });
    this.mat.alphaToCoverage = false; // A2C + MSAA left 1 px sky-depth seams on blurred far cards (POST)
    this.soft = new THREE.MeshBasicMaterial({ map: blank, transparent: true, depthWrite: false, side: THREE.DoubleSide });
    this.blob = blobMaterial(blank);
    this.mesh = new THREE.Mesh(CARD, this.mat);
    this.mesh.visible = false; this.mesh.layers.set(NOINK);
    parent.add(this.mesh);
  }
  use(soft: boolean) { this.mesh.material = soft ? this.soft : this.mat; }
  bind() {
    const t = this.r?.tex;
    if (!t) return;
    if (this.r!.key.includes("|blob|")) {
      // no mipmaps: at grazing views the mip chain averages the blob with its white surround and it fades out
      if (t.generateMipmaps) { t.generateMipmaps = false; t.minFilter = THREE.LinearFilter; t.needsUpdate = true; }
      this.blob.map = t; this.mesh.material = this.blob; this.mesh.renderOrder = 0.5;
    }
    else { this.mat.map = t; this.soft.map = t; this.mesh.renderOrder = 0; }
  }
}

// ---------------- placements ----------------
export type Place = {
  key: string; draw: (p: Pen) => void; x: number; y: number; z: number;
  scale?: number; mirror?: boolean; yaw?: number; geo?: "body" | "swing"; roll?: number; size?: [number, number, number];
};
export type FxPlace = { key: string; cw: number; ch: number; draw: (p: Pen) => void; x: number; y: number; z: number; w: number; h: number; flat?: boolean; rot?: number; soft?: boolean };
/** sun = world direction TOWARD the sun (optional: when absent the scene's shadow-casting light is used) */
export type CamInfo = { pos: THREE.Vector3; right: THREE.Vector3; sun?: THREE.Vector3 };

const hh = (i: number, s = 0) => { const v = Math.sin(i * 127.1 + s * 311.7) * 43758.5453; return v - Math.floor(v); };
const q = (v: number, n = 120) => Math.round(v * n) / n;
const vOf = (i: number) => (i * 7 + (i >> 2)) % 4;
/** head-shape seed: 7 shapes, so marching soldiers in step still share canvases */
const seedOf = (i: number) => ((i * 5 + 3) % 7) + 1;
/** drawing resolution by distance: [canvas w, h, scale from the 600 x 1000 design]; sized for the 1440 x 2560 final */
const tier = (d: number): [number, number, number] =>
  d < 3.2 ? [1800, 3000, 3.0] : d < 6.5 ? [1080, 1800, 1.8] : d < 16 ? [480, 800, 0.8] : [240, 400, 0.4];

// ---------------- light ----------------
const SUN = new THREE.Vector3(0.5, 0.75, -0.4).normalize();
const tmp = new THREE.Vector3();
let LNAME: "day" | "golden" = "day";
export const setLight = (sun: THREE.Vector3, light: string) => { SUN.copy(sun).normalize(); LNAME = light === "golden" ? "golden" : "day"; };
const sunOf = (root: THREE.Object3D) => {
  let s: THREE.DirectionalLight | null = null;
  root.traverse((o) => { if (!s && o instanceof THREE.DirectionalLight && o.castShadow) s = o; });
  return s as THREE.DirectionalLight | null;
};
/** the sun of the world that is calling: the attached root whose sun target sits on this camera's view axis */
const findSun = (cam: CamInfo, out: THREE.Vector3) => {
  if (cam.sun) return out.copy(cam.sun).normalize();
  let best: THREE.DirectionalLight | null = null, err = Infinity;
  for (const r of ROOTS) {
    if (!r.parent) continue;
    const s = sunOf(r);
    if (!s) continue;
    const d = tmp.copy(s.target.position).sub(cam.pos), e = Math.abs(d.dot(cam.right)) / (d.length() || 1);
    if (e < err) { err = e; best = s; }
  }
  return best ? out.copy(best.position).sub(best.target.position).normalize() : out;
};
/** canvas angle the sun comes FROM on an upright card facing the camera, in 45-degree steps (small texture cache) */
const light2D = (cam: CamInfo, mirror: boolean) => {
  const sx = SUN.dot(cam.right) * (mirror ? -1 : 1), sy = -SUN.y;
  return Math.round(Math.atan2(sy, sx) / (Math.PI / 4)) * (Math.PI / 4);
};

/** front / side view and mirroring for someone at (x, z) walking along (dx, dz); fs = foreshortening of the walk */
const viewOf = (cam: CamInfo, x: number, z: number, dx: number, dz: number) => {
  const tx = cam.pos.x - x, tz = cam.pos.z - z, tl = Math.hypot(tx, tz) || 1;
  const c = (tx * dx + tz * dz) / tl;
  return { side: c < 0.57, mirror: dx * cam.right.x + dz * cam.right.z < 0, fs: Math.round(Math.sqrt(Math.max(0, 1 - c * c)) * 20) / 20 };
};

// ---------------- life: blinks and reaction timing ----------------
/** reference expression and action changes land 0-3 f before the word onset */
const LEAD = 2 / FPS;
/** eyelid 0 open .. 1 shut. Reference: gaps 0.5-2.3 s, 4-frame blink half / shut / shut / half, plus a blink across
 *  every expression swap (the shut frames hide the swap) */
const LID = [0.5, 1, 1, 0.5];

const lidAt = (t: number, i: number, swaps: number[] = []) => {
  const f = Math.round(t * FPS);
  for (const ts of swaps) { const k = f - Math.round((ts - LEAD) * FPS) + 1; if (k >= 0 && k < 4) return LID[k]; }
  let s = Math.round(-60 * hh(i, 9));
  for (let n = 0; s <= f && n < 400; n++) {
    const k = f - s;
    if (k >= 0 && k < 4) return LID[k];
    s += Math.round(15 + 54 * hh(i * 31 + n, 13)); // next blink 0.5-2.3 s later
  }
  return 0;
};
const fkey = (o: object) => JSON.stringify(o, (_k, v) => (typeof v === "number" ? q(v) : v));

type Who = { i: number; o: Outfit; okey: string };
/** a patchwork quilt drawn over a lying card's body, from just under the chin down past the feet (card space, the card
 *  is then rolled 90 degrees so this runs along the bed) */
const quiltOver = (p: Pen, cols: string[]) => {
  const top = ANCHOR.chin[1] + 14, hw = 122, y1 = 1000;
  const shape: [number, number][] = [[300 - hw, y1], [300 - hw, top + 70], [300 - hw + 14, top + 26], [300 - 70, top + 4], [300, top], [300 + 70, top + 4], [300 + hw - 14, top + 26], [300 + hw, top + 70], [300 + hw, y1]];
  p.poly(shape, cols[0], 9);
  p.clip(shape, () => { let k = 0; for (let y = top - 10; y < y1; y += 104) for (let x = 300 - hw; x < 300 + hw; x += 82) { p.g.fillStyle = cols[(k++ * 3 + Math.floor(y / 104)) % cols.length]; p.g.fillRect(x, y, 82, 104); }
    p.g.fillStyle = "#f6f3ea"; p.g.fillRect(300 - hw, top - 10, 2 * hw, 44); // the turned-down sheet
    p.g.strokeStyle = "rgba(255,255,255,0.6)"; p.g.setLineDash([12, 10]); p.g.lineWidth = 4; for (let y = top + 136; y < y1; y += 104) { p.g.beginPath(); p.g.moveTo(300 - hw, y); p.g.lineTo(300 + hw, y); p.g.stroke(); } p.g.setLineDash([]); });
  p.stroke([[300 - hw + 4, top + 34], [300 + hw - 4, top + 34]], 5);
  p.poly(shape, null, 9);
};
/** one character drawing in the 600 x 1000 design space, sized by distance, lit from the scene's sun */
const person = (cam: CamInfo, who: Who, x: number, y: number, z: number, view: { side: boolean; mirror: boolean }, fo: FrontOpts, so: SideOpts, scale = 1, quilt: string[] | null = null): Place & { tierKey: string } => {
  const d = cam.pos.distanceTo(tmp.set(x, y + 1.2, z)) / scale;
  const [w, h, k] = tier(d);
  const mirror = view.side && view.mirror, light = light2D(cam, mirror), seed = seedOf(who.i);
  const f2: FrontOpts = { ...fo, light, seed }, s2: SideOpts = { ...so, light, seed };
  const key = view.side ? `S|${who.okey}|${fkey(s2)}` : `F|${who.okey}|${fkey(f2)}`;
  return {
    key: key + (quilt ? "|quilt" : ""), x, y, z, scale, mirror, tierKey: `${w}`,
    draw: (p) => { if (view.side) bodySide(p, who.o, s2); else { bodyFront(p, who.o, f2); if (quilt) quiltOver(p, quilt); } },
    size: [w, h, k],
  };
};

/** ground shadow under a standing / sitting card (review rounds 2-4), multiply, blue-violet: a TIGHT contact pool right under
 *  the feet (~.5 on screen at the core) so nobody floats, plus by day (cards cast no real shadow) a lighter soft tail
 *  stretched AWAY from the sun, length ~1.6 m / tan(sun elevation), capped. Golden: world.ts casts real card shadows. */
const CONTACT: Record<"day" | "golden", [number, number, number]> = { day: [0.2, 0.21, 0.33], golden: [0.24, 0.2, 0.33] };
const TAIL: [number, number, number] = [0.42, 0.44, 0.62];
const toSrgb = (v: number) => { const c = clamp01(v); return c <= 0.0031308 ? 12.92 * c : 1.055 * c ** (1 / 2.4) - 0.055; };
const hexOf = (c: [number, number, number], k: number) => "#" + c.map((v) => Math.round(255 * toSrgb(1 - (1 - v) * k)).toString(16).padStart(2, "0")).join("");
const blob = (out: Stage, x: number, y: number, z: number, sc = 1, k = 1) => {
  const hl = Math.hypot(SUN.x, SUN.z) || 1, ox = -SUN.x / hl, oz = -SUN.z / hl, rot = Math.atan2(-ox, -oz);
  if (LNAME === "day") {
    const el = Math.asin(Math.min(0.99, Math.max(0.1, SUN.y)));
    const len = Math.min(2.4, Math.max(0.5, 1.6 / Math.tan(el))) * sc, h = len + 0.55 * sc, c = 0.3 * h; // feet at v = .2 of the card
    const tc = hexOf(TAIL, k);
    out.fx.push({ key: `blob|shadow|${tc}`, cw: 128, ch: 256, draw: (p) => fxShadow(p, tc), x: x + ox * c, y: y + 0.018, z: z + oz * c,
      w: 0.72 * sc, h, flat: true, rot });
  }
  const cc = hexOf(CONTACT[LNAME], k);
  out.fx.push({ key: `blob|contact|${cc}`, cw: 128, ch: 128, draw: (p) => fxContact(p, cc), x: x + ox * 0.03 * sc, y: y + 0.022, z: z + oz * 0.03 * sc,
    w: 0.52 * sc, h: 0.4 * sc, flat: true, rot });
};


export type Line3 = { a: V3; b: V3 };
export type Stage = { places: Place[]; fx: FxPlace[]; lines: Line3[] };
// ---------------- the cast (all invented, ordinary people) ----------------
const W0 = (jacket: string, pants: string, skin: string, extra: Partial<Outfit> = {}): Outfit => ({ jacket, pants, boots: "#2b2018", hat: "cap", cap: "#5a4a3a", skin, plain: true, ...extra });
const C = {
  worker: { i: 3, o: W0("#6a5a4a", "#4a4038", "#f0c8a0", { cap: "#7a6a52", moustache: "#5a3b2a", tie: "#c0392b" }), okey: "worker" },
  patient: { i: 7, o: { jacket: "#f4f1ea", pants: "#e8e2d6", boots: "#f0c8a0", hat: "beanie", cap: "#f4f1ea", skin: "#e8d84e", plain: true, stubble: "#8a6a4a" }, okey: "patient" },
  ben: { i: 12, o: { jacket: "#2f3f5c", pants: "#2a2a33", boots: "#1d1f26", hat: "tophat", skin: "#e9c39f", moustache: "#3a2a20", lapels: true, tie: "#c0392b", build: "adult" }, okey: "ben" },
  miles: { i: 36, o: { jacket: "#6a2d2d", pants: "#3a3d46", boots: "#1d1f26", hat: "tophat", skin: "#f0c8a0", moustache: "#5a3b2a", lapels: true, tie: "#f2c12e", build: "stout" }, okey: "miles" },
  docA: { i: 51, o: { jacket: "#3a3a52", pants: "#2a2a33", boots: "#1d1f26", hat: "tophat", skin: "#f0c8a0", moustache: "#8a8a8a", lapels: true, tie: "#f4f1ea", build: "adult", glasses: "#2b2b33" }, okey: "docA" },
  docB: { i: 54, o: { jacket: "#4a3a2a", pants: "#2a2a33", boots: "#1d1f26", hat: "tophat", skin: "#e9c39f", lapels: true, tie: "#2a9d8f", build: "stout", moustache: "#2a201a" }, okey: "docB" },
  heinz: { i: 14, o: { jacket: "#8a2b2b", pants: "#3a3d46", boots: "#2b2018", hat: "tophat", skin: "#e9c39f", moustache: "#3a2a20", lapels: true, tie: "#f4f1ea", build: "adult" }, okey: "heinz" },
  mary: { i: 16, o: { jacket: "#3a3d52", pants: "#2b2b33", boots: "#2b2018", hat: "bonnet", skin: "#ecd0b6", plain: true, dress: "#3a3d52", palla: "#8a4a6a", glasses: "#2b2b33" }, okey: "mary" },
  w1: { i: 20, o: W0("#7b2d2d", "#4a4038", "#c99067", { cap: "#3a3d46" }), okey: "w1" },
  w2: { i: 23, o: { jacket: "#f6f2e6", pants: "#4a4038", boots: "#2b2018", hat: "hair", hair: "#5a3b2a", skin: "#f0c8a0", plain: true, dress: "#2457c5", palla: "#c0392b" }, okey: "w2" },
  w3: { i: 26, o: W0("#3d6a4a", "#3a3438", "#f5c9a0", { cap: "#6a5a4a", stubble: "#5a3a2a" }), okey: "w3" },
  w4: { i: 30, o: { jacket: "#f6f2e6", pants: "#4a4038", boots: "#2b2018", hat: "hair", hair: "#c2562b", skin: "#f5c9a0", plain: true, dress: "#7b5ac9", palla: "#e9c46a" }, okey: "w4" },
  late: { i: 33, o: W0("#c0663a", "#3a3438", "#e9c39f", { cap: "#2457c5", tie: "#f2c12e" }), okey: "late" },
  nA: { i: 39, o: { jacket: "#f4f1ea", pants: "#e8e2d6", boots: "#f0c8a0", hat: "beanie", cap: "#c0392b", skin: "#c99067", plain: true, beard: "#2a201a" }, okey: "nA" },
  nB: { i: 42, o: { jacket: "#f6f2e6", pants: "#e8e2d6", boots: "#f0c8a0", hat: "hair", hair: "#d8d8dc", skin: "#ecd0b6", plain: true, dress: "#f4f1ea", palla: "#2a9d8f" }, okey: "nB" },
  guy: { i: 48, o: { jacket: "#5a5f6e", pants: "#2e3a52", boots: "#e8e8ee", hat: "hair", hair: "#3a2a20", skin: "#f5c9a0", hoodie: "#f4f1ea" }, okey: "guy" },
} satisfies Record<string, Who>;
/** one character: front card unless walking across the lens (side card); blinks; contact blob unless told not to */
type Act = {
  who: Who; p: V3; expr: Expr; t: number; mode?: FrontOpts["mode"]; prop?: Prop; wave?: number; look?: number; facing?: -1 | 0 | 1;
  tilt?: number; headTilt?: number; walk?: { dx: number; dz: number; phase: number }; blob?: boolean; blinkSeed?: number;
  seat?: number; roll?: number; quilt?: string[]; stroll?: number;
};
const END = TOTAL / FPS;
let CUR = 0; // shot being staged (acting tracks are per shot)
const put = (out: Stage, cam: CamInfo, a0: Act): Place => {
  let a = a0, pose: FrontOpts["pose"] = undefined, hop = 0, swaps: number[] = [];
  const tr = TRACKS[CUR]?.[a0.who.okey];
  const pr = PROPS[CUR], prop = pr && a0.who.okey in pr ? pr[a0.who.okey] : a0.prop;
  if (tr && !a0.walk) {
    const fade = clamp01(Math.min(a0.t, END - a0.t) / 0.4);
    const r = evalTrack(tr, a0.t, a0.who.i, fade);
    a = { ...a0, expr: r.expr ?? a0.expr, tilt: r.tilt, headTilt: r.headTilt, look: r.look ?? a0.look, wave: undefined };
    pose = r.pose; hop = r.hop; swaps = r.swaps;
  }
  const [x, y, z] = a.p;
  const blink = a.expr === "shock" || a.expr === "whistle" || a.t < 0.4 || a.t > END - 0.4 ? 0 : lidAt(a.t, a.blinkSeed ?? a.who.i, swaps);
  let view = { side: false, mirror: false, fs: 1 };
  if (a.walk) view = viewOf(cam, x, z, a.walk.dx, a.walk.dz);
  const fo: FrontOpts = { phase: a.walk?.phase ?? a.stroll ?? 0, expr: a.expr, mode: a.seat ? "sit" : a.mode ?? (a.walk || a.stroll !== undefined ? "stroll" : "stand"), look: a.look ?? 0, blink, prop: prop ?? null,
    wave: a.wave, tilt: a.tilt ?? 0, headTilt: a.headTilt ?? 0, facing: a.facing ?? 0, lift: 50, pose, seatH: a.seat ? a.seat / SU : undefined };
  const so: SideOpts = { phase: a.walk?.phase ?? 0, expr: a.expr, mode: "march", blink, stomp: 0.65, stride: view.fs * 0.8 };
  const pl = person(cam, a.who, x, y + hop, z, view, fo, so, 1, a.quilt ?? null);
  if (a.roll) { pl.roll = a.roll; pl.yaw = 0; pl.mirror = false; }
  out.places.push(pl);
  if (a.blob !== false) blob(out, x, y, z, 1, hop > 0.02 ? Math.max(0.55, 1 - hop * 2.5) : 1);
  return pl;
};
/** world position of a canvas point of a placed front card (the card faces the camera; mirror and scale applied) */
const scratch = (() => { const c = document.createElement("canvas"); c.width = 8; c.height = 8; return new Pen(c.getContext("2d")!); })();
const ANC = new Map<string, typeof ANCHOR>();
const anchorsOf = (pl: Place) => {
  let a = ANC.get(pl.key);
  if (!a) { pl.draw(scratch); a = JSON.parse(JSON.stringify(ANCHOR)) as typeof ANCHOR; ANC.set(pl.key, a); if (ANC.size > 4000) ANC.clear(); }
  return a;
};
const toWorld = (cam: CamInfo, pl: Place, c: [number, number]): V3 => {
  const yaw = pl.yaw ?? Math.atan2(cam.pos.x - pl.x, cam.pos.z - pl.z), s = pl.scale ?? 1, X = (c[0] - 300) * SU * s * (pl.mirror ? -1 : 1), Y = (975 - c[1]) * SU * s;
  return [pl.x + X * Math.cos(yaw), pl.y + Y, pl.z - X * Math.sin(yaw)];
};
const norm = (v: V3): V3 => { const l = Math.hypot(...v) || 1; return [v[0] / l, v[1] / l, v[2] / l]; };

// ---------------- effect cards ----------------
const penny = (p: Pen) => { p.ell(128, 128, 100, 100, "#c87a3a", 10); p.ell(128, 128, 70, 70, null, 6); p.ell(108, 108, 18, 12, "#e8a868", 0); };
const pea = (p: Pen) => { p.ell(64, 64, 44, 44, "#9ac44a", 7); p.ell(52, 50, 14, 10, "#d8f08a", 0); };
const zee = (k: number) => (p: Pen) => { const s = 0.8 + k * 0.2; p.stroke([[60, 60], [196, 60], [60, 196], [196, 196]].map(([x, y]) => [128 + (x - 128) * s, 128 + (y - 128) * s] as [number, number]), 22, "#f4f1ea"); };
const zeeInk = (k: number) => (p: Pen) => { const s = 0.8 + k * 0.2; const pts = [[60, 60], [196, 60], [60, 196], [196, 196]].map(([x, y]) => [128 + (x - 128) * s, 128 + (y - 128) * s] as [number, number]); p.stroke(pts, 34, INK); p.stroke(pts, 20, "#f4f1ea"); };
const ringFx = (p: Pen) => { for (const r of [70, 110]) for (const s2 of [-1, 1]) p.arc(128 + s2 * 10, 128, r, r, s2 > 0 ? -50 : 130, s2 > 0 ? 50 : 230, 10); };
const q2 = (v: number, n = 24) => Math.round(v * n) / n;
/** coins fluttering up and away from (x, y, z) (seconds since t0) */
const coins = (out: Stage, t: number, t0: number, x: number, y: number, z: number, n: number) => {
  for (let i = 0; i < n; i++) {
    const u = clamp01((t - t0 - i * 0.08) / 1.1); if (u <= 0 || u >= 1) continue;
    const a = hh(i, 2) * Math.PI * 2, r = 0.25 + u * 1.2, bx = x + Math.cos(a) * r, bz = z + Math.sin(a) * r * 0.5, by = y + 0.2 + u * 1.3 - u * u * 0.6;
    out.fx.push({ key: "penny", cw: 256, ch: 256, draw: penny, x: bx, y: by, z: bz, w: 0.16, h: 0.16 * (0.4 + 0.6 * Math.abs(Math.cos((t + i) * 7))), rot: q2(Math.sin((t + i) * 6) * 0.5, 12) });
  }
};
/** Zzz rising from a sleeper's head */
const zzz = (out: Stage, t: number, h: V3) => {
  for (let k = 0; k < 3; k++) { const u = ((t * 0.55 + k / 3) % 1);
    out.fx.push({ key: "zee" + k, cw: 256, ch: 256, draw: zeeInk(k), x: h[0] + 0.15 + u * 0.35, y: h[1] + 0.25 + u * 0.55, z: h[2] + 0.05, w: 0.14 + 0.1 * u, h: 0.14 + 0.1 * u, rot: q2(0.25 * Math.sin(u * 4), 12) }); }
};
/** a tap burst where the pole tip meets the glass (3 frames from each contact) */
const tapBurst = (out: Stage, t: number, tip: V3) => {
  const ph = (t * 2.6) % 1; if (ph < 0.5 || ph > 0.64) return;
  const u = (ph - 0.5) / 0.14; out.fx.push({ key: "tap" + Math.round(u * 4), cw: 512, ch: 512, draw: (p) => fxBurst(p, Math.round(u * 4) / 4, "#fff3b0", 8, 30, 170), x: tip[0], y: tip[1], z: tip[2] + 0.04, w: 0.32, h: 0.32 });
};

// ---------------- effect drawings (ketchup story) ----------------
const bottleDraw = (l1: string, l2: string, cross: boolean) => (p: Pen) => {
  const g = p.g;
  p.poly([[100, 70], [156, 70], [162, 150], [94, 150]], "#c4251f", 10);
  p.poly([[88, 22], [168, 22], [168, 72], [88, 72]], "#f4f1ea", 9);
  p.poly([[66, 140], [190, 140], [206, 190], [206, 470], [186, 496], [70, 496], [50, 470], [50, 190]], "#c4251f", 10);
  p.stroke([[72, 200], [72, 440]], 8, "#e8665c");
  p.poly([[60, 225], [196, 225], [196, 425], [60, 425]], "#fff6dc", 7);
  g.textAlign = "center"; g.fillStyle = "#1d1f26"; g.font = "900 25px sans-serif"; g.fillText(l1, 128, 275);
  if (l2) { g.font = "900 22px sans-serif"; g.fillStyle = "#c4251f"; g.fillText(l2, 128, 312); }
  if (cross) { g.fillStyle = "#c4251f"; g.fillRect(118, 335, 20, 66); g.fillRect(95, 358, 66, 20); }
};
const tomatoDraw = (p: Pen) => {
  p.ell(128, 142, 100, 92, "#e03a2a", 10); p.ell(92, 104, 24, 14, "#f4958a", 0);
  p.poly([[128, 66], [150, 88], [180, 76], [160, 104], [128, 98], [98, 104], [76, 76], [106, 88]], "#3f9a3a", 8);
  p.stroke([[128, 70], [136, 34]], 10, "#3f9a3a");
};
const skullDraw = (p: Pen) => {
  p.ell(128, 108, 72, 64, "#f4f1ea", 9); p.poly([[92, 150], [164, 150], [158, 206], [98, 206]], "#f4f1ea", 9);
  p.ell(102, 112, 17, 21, "#1d1f26", 0); p.ell(154, 112, 17, 21, "#1d1f26", 0); p.poly([[128, 128], [118, 150], [138, 150]], "#1d1f26", 0);
  for (const x of [112, 128, 144]) p.stroke([[x, 168], [x, 204]], 5, "#1d1f26");
};
const pillDraw = (p: Pen) => {
  p.rot = [0.6, 128, 128];
  p.ell(78, 128, 52, 52, "#d7262e", 10); p.ell(178, 128, 52, 52, "#f4f1ea", 10);
  p.poly([[78, 76], [128, 76], [128, 180], [78, 180]], "#d7262e", 0); p.poly([[128, 76], [178, 76], [178, 180], [128, 180]], "#f4f1ea", 0);
  p.stroke([[78, 76], [178, 76]], 10); p.stroke([[78, 180], [178, 180]], 10); p.stroke([[128, 76], [128, 180]], 7);
  p.ell(60, 110, 14, 8, "#f08a7a", 0);
  p.rot = null;
};
const qDraw = (p: Pen) => { const g = p.g; g.textAlign = "center"; g.font = "900 220px sans-serif"; g.lineWidth = 26; g.strokeStyle = INK; g.lineJoin = "round"; g.strokeText("?", 128, 210); g.fillStyle = "#f2c12e"; g.fillText("?", 128, 210); };
const noteDraw = (p: Pen) => { p.stroke([[150, 190], [150, 50], [200, 76]], 16, INK); p.stroke([[150, 190], [150, 50], [200, 76]], 8, "#1d1f26"); p.ell(112, 196, 40, 30, "#2457c5", 9); };
const heartDraw = (p: Pen) => { const g = p.g; g.beginPath(); g.moveTo(128, 214); g.bezierCurveTo(6, 130, 38, 26, 128, 90); g.bezierCurveTo(218, 26, 250, 130, 128, 214); g.closePath(); g.fillStyle = "#e8344a"; g.fill(); g.lineWidth = 10; g.strokeStyle = INK; g.lineJoin = "round"; g.stroke(); };
const dropDraw = (p: Pen) => { p.ell(64, 64, 40, 40, "#d7262e", 6); p.ell(52, 50, 10, 7, "#f08a7a", 0); };
const xDraw = (p: Pen) => { p.stroke([[40, 40], [216, 216]], 34, INK); p.stroke([[216, 40], [40, 216]], 34, INK); p.stroke([[40, 40], [216, 216]], 20, "#e02020"); p.stroke([[216, 40], [40, 216]], 20, "#e02020"); };
const noTomatoDraw = (p: Pen) => { p.ell(128, 130, 86, 80, "#e03a2a", 8); p.poly([[128, 64], [146, 80], [170, 72], [154, 94], [128, 90], [102, 94], [86, 72], [110, 80]], "#3f9a3a", 6);
  p.arc(128, 128, 112, 112, 0, 360, 26, INK); p.arc(128, 128, 112, 112, 0, 360, 14, "#e02020"); p.stroke([[50, 50], [206, 206]], 26, INK); p.stroke([[50, 50], [206, 206]], 14, "#e02020"); };
const boardDraw = (lines: string[], bg: string, fg: string) => (p: Pen) => {
  const g = p.g; p.poly([[14, 14], [498, 14], [498, 242], [14, 242]], bg, 12);
  const n = lines.length, lh = 200 / n; g.textAlign = "center"; g.fillStyle = fg;
  lines.forEach((l, i) => { const sz = Math.min(0.8 * lh, 440 / (l.length * 0.66)); g.font = "900 " + Math.round(sz) + "px sans-serif"; g.fillText(l, 256, 30 + lh * (i + 0.8)); });
};
const stampDraw = (p: Pen) => { const g = p.g; g.save(); g.translate(256, 128); g.rotate(-0.3); g.strokeStyle = "#d02020"; g.lineWidth = 14; g.strokeRect(-190, -76, 380, 152); g.fillStyle = "#d02020"; g.font = "900 120px sans-serif"; g.textAlign = "center"; g.fillText("FAKE", 0, 42); g.restore(); };
const sparkDraw = (k: number) => (p: Pen) => fxBurst(p, k / 4, "#fff3b0", 8, 30, 150);

// ---------------- staging per shot ----------------
const A = (s: SetName, p: V3): V3 => at(s, p[0], p[1], p[2]);
export const stage = (id: number, t: number, cam: CamInfo): Stage => {
  const out: Stage = { places: [], fx: [], lines: [] };
  const S = SHOTS[id - 1];
  CUR = id;
  if (cam.sun) setLight(cam.sun, S.light === "golden" ? "golden" : "day");
  const set = S.set, Q = (p: V3) => A(set, p);
  const fx = (key: string, cw: number, ch: number, draw: (p: Pen) => void, p: V3, w: number, h: number, rot?: number) => out.fx.push({ key, cw, ch, draw, x: p[0], y: p[1], z: p[2], w, h, rot });
  const hearts = (p: V3, n: number) => { for (let k = 0; k < n; k++) { const u = (t * 0.45 + k / n) % 1; fx("heart", 256, 256, heartDraw, [p[0] + 0.3 * Math.sin(k * 2.1 + u * 3), p[1] + 0.2 + u * 0.9, p[2] + 0.1], 0.16 + 0.1 * u, 0.16 + 0.1 * u, q2(0.2 * Math.sin(u * 5 + k), 12)); } };
  const bottle = (p: V3, h: number, l1 = "KETCHUP", l2 = "", cross = false, rot = 0) => fx("btl" + l1 + l2 + cross, 256, 512, bottleDraw(l1, l2, cross), p, h * 0.5, h, rot);
  switch (set) {
    case "shop": {
      const hero = Q([0.0, 1.46, -3.9]);
      if (id === 1) { put(out, cam, { who: C.worker, p: Q(P.worker), t, expr: "nervous", facing: -1, look: -0.6 }); bottle(hero, 0.84); }
      else if (id === 2) { put(out, cam, { who: C.worker, p: Q(P.worker), t, expr: "nervous", facing: -1, look: -0.6 }); bottle(hero, 0.84, "KETCHUP", "MEDICINE", true); if (t > 2.93) fx("sp" + Math.floor((t - 2.93) * 12) % 4, 512, 512, sparkDraw(Math.floor((t - 2.93) * 12) % 4), [hero[0] - 0.1, hero[1] + 0.5, hero[2] + 0.1], 0.5, 0.5); }
      else if (id === 9) { put(out, cam, { who: C.ben, p: Q(P.worker), t, expr: "smile", facing: -1, prop: "scroll" }); bottle(hero, 0.84, "KETCHUP", "MEDICINE", true); }
      else if (id === 10) {
        const sh = t > 16.2 ? 0.06 * Math.sin(t * 30) : 0;
        bottle([hero[0], hero[1] + 0.05, hero[2]], 0.84, "KETCHUP", "MEDICINE", true, sh);
        const neck: V3 = Q([0.0, 1.93, -3.86]);
        for (let i = 0; i < 10; i++) { const u = clamp01((t - 16.2 - i * 0.15) / 0.55); if (u <= 0) continue;
          const to: V3 = Q([0.5 + (i % 4) * 0.12 - 0.1 * (i % 2), 0.82, -3.95 - (i % 3) * 0.08]);
          fx("pill", 256, 256, pillDraw, [lerp(neck[0], to[0], u), lerp(neck[1], to[1], u) + Math.sin(u * Math.PI) * 0.2, lerp(neck[2], to[2], u)], 0.17, 0.17, q2(u * 6 + i, 12)); }
      }
      else if (id === 17) { put(out, cam, { who: C.worker, p: Q(P.worker), t, expr: "nervous", facing: -1 });
        fx("pill", 256, 256, pillDraw, Q([0.5, 1.2, -2.5]), 0.45, 0.45); fx("notomato", 256, 256, noTomatoDraw, Q([1.35, 2.0, -2.5]), 0.6 * (t > 29.7 ? 1 : 0.01 + 0.99 * clamp01((t - 29.73) / 0.15)), 0.6); }
      else if (id === 18) {
        const run = clamp01((t - 31.55) / 0.75), x = lerp(P.worker[0], 6.5, run * run);
        if (run <= 0) put(out, cam, { who: C.worker, p: Q(P.worker), t, expr: "pained", facing: -1 });
        else put(out, cam, { who: C.worker, p: Q([x, PH, P.worker[2]]), t, expr: "shock", walk: { dx: 1, dz: 0, phase: t * 3.4 } });
        fx("lax", 512, 256, boardDraw(["LAXATIVE"], "#f4f1ea", "#c0392b"), Q([1.9, 1.95, -3.2]), 0.95, 0.48);
        fx("pill", 256, 256, pillDraw, Q([1.9, 1.35, -3.2]), 0.4, 0.4);
      }
      break;
    }
    case "bed": {
      put(out, cam, { who: C.patient, p: Q([HEADX, HEADY - 1.44, BZ - 0.04]), t, expr: "pained", blob: false, headTilt: 8 });
      break;
    }
    case "gate": {
      if (id === 13) {
        const ws = [C.w1, C.w2, C.w3, C.w4, C.late];
        ws.forEach((w, i) => { const u = (t - 22.35) / 2.0 + 0.18 * i + 0.25; if (u < 0 || u > 1.05) return;
          const a: V3 = [7.5 + (i % 2) * 1.2, 0, 2.0 + (i % 3) * 0.6], b: V3 = [-0.4 + (i % 3) * 0.4, 0, -9.0], x = lerp(a[0], b[0], u), z = lerp(a[2], b[2], u);
          put(out, cam, { who: w, p: Q([x, 0, z]), t, expr: i % 2 ? "grin" : "smile", walk: { dx: b[0] - a[0], dz: b[2] - a[2], phase: t * 1.9 + i * 0.3 } }); });
        put(out, cam, { who: C.miles, p: Q(MILES), t, expr: "grin", facing: 1 });
        if (t > 22.5) coins(out, t, 22.5, Q(MILES)[0], 1.0, Q(MILES)[2] + 0.1, 6);
      } else {
        put(out, cam, { who: C.miles, p: Q(MILES), t, expr: "smug", prop: "ledger", facing: 1 });
        if (id === 12) fx("mboard", 512, 256, boardDraw(["DR. MILES'", "COMPOUND EXTRACT", "OF TOMATO"], "#fff0b8", "#b01e24"), Q([0.95, 1.75, -6.9]), 1.15, 0.58);
      }
      break;
    }
    case "london": {
      const sellers: [Who, V3][] = [[C.w2, [1.0, 0, -2.9]], [C.mary, MARY], [C.w3, [3.8, 0, -2.9]]];
      if (id === 14) { sellers.forEach(([w, p], i) => { put(out, cam, { who: w, p: Q(p), t, expr: i === 1 ? "smug" : "grin" }); bottle(Q([p[0] + 0.5, 0.5, p[2] + 0.35]), 0.6, "TOMATO", "PILLS"); }); }
      else {
        put(out, cam, { who: C.mary, p: Q(MARY), t, expr: "grin" });
        for (let k = 0; k < 3; k++) { const u = (t * 0.7 + k / 3) % 1; fx("note", 256, 256, noteDraw, Q([MARY[0] + (k - 1) * 0.5 + 0.2 * Math.sin(u * 6), 2.0 + u * 0.8, MARY[2] + 0.2]), 0.24, 0.24, q2(0.3 * Math.sin(u * 5 + k), 12)); }
        if (id === 16) fx("jingle", 512, 256, boardDraw(["TOMATO PILLS", "WILL CURE", "ALL YOUR ILLS"], "#fff0b8", "#b01e24"), Q([MARY[0], 2.65, -3.4]), 1.8, 0.9);
      }
      break;
    }
    case "street": {
      if (id === 3 || id === 4) {
        put(out, cam, { who: C.nA, p: Q([-0.85, PH + 0.16, FZ + 0.42]), t, expr: "shock", facing: 1 }); put(out, cam, { who: C.nB, p: Q([3.25, PH + 0.16, FZ + 0.42]), t, expr: "nervous", facing: -1 });
        const b = 1 + 0.06 * Math.sin(t * 6);
        fx("tomato", 256, 256, tomatoDraw, Q([1.2, 0.5, -4.7]), 0.55, 0.55);
        if (id === 4 || t > 4.6) fx("skull", 256, 256, skullDraw, Q([1.2, 1.15, -4.6]), 0.4 * b, 0.4 * b, q2(0.15 * Math.sin(t * 7), 12));
      } else if (id === 5) { const x = lerp(-5.5, BEN[0], clamp01((t - 6.39) / 1.9)); put(out, cam, { who: C.ben, p: Q([x, PH, -5.2]), t, expr: "smile", facing: -1, prop: "scroll", stroll: x * 0.55 }); }
      else if (id === 6 || id === 7) put(out, cam, { who: C.ben, p: Q(BEN), t, expr: "grin", facing: -1, prop: "scroll" });
      else if (id === 19) {
        put(out, cam, { who: C.docA, p: Q(D1), t, expr: "stern", facing: 1 }); put(out, cam, { who: C.docB, p: Q(D2), t, expr: "stern", facing: -1 });
        const pop = (t0: number) => 0.01 + 0.99 * clamp01((t - t0) / 0.2);
        fx("qm", 256, 256, qDraw, Q([D1[0], 2.15, -4.8]), 0.4 * pop(32.6), 0.4 * pop(32.6)); fx("qm", 256, 256, qDraw, Q([D2[0], 2.15, -4.8]), 0.4 * pop(33.0), 0.4 * pop(33.0), 0.15);
      } else if (id === 20) {
        put(out, cam, { who: C.docA, p: Q(D1), t, expr: "dazed", facing: 1 }); put(out, cam, { who: C.docB, p: Q(D2), t, expr: "shock", facing: -1 });
        const f = clamp01((t - 33.9) / 0.5), by = lerp(2.3, 0.4, f * f);
        if (f < 1) bottle(Q([1.2, by, -4.6]), 0.7, "TOMATO", "PILLS", false, q2(f * 1.2, 12));
        else { const k = Math.floor((t - 34.4) * 12); if (k < 4) fx("brk" + k, 512, 512, sparkDraw(k), Q([1.2, 0.5, -4.5]), 0.9, 0.9);
          for (let i = 0; i < 7; i++) { const u = clamp01((t - 34.4) / 0.5); fx("pill", 256, 256, pillDraw, Q([1.2 + (i - 3) * 0.16 * u, 0.3 + 0.25 * Math.sin(u * Math.PI) * (1 - i * 0.05), -4.5 + (i % 3) * 0.15]), 0.16, 0.16, q2(i + u * 4, 12)); } }
      } else {
        const g = put(out, cam, { who: C.guy, p: Q(GP), t, expr: "grin", facing: 0, prop: id === 29 ? null : "chips" });
        const an = anchorsOf(g), hr = toWorld(cam, g, an.r);
        if (id === 25) bottle(Q([0.7, PH + 0.38, -4.5]), 0.72);
        else if (id === 26) { const bp = Q([0.95, 1.5, -4.4]); bottle(bp, 0.8, "KETCHUP", "MEDICINE", true, 0.1); fx("fake", 512, 256, stampDraw, [bp[0] + 0.05, bp[1] + 0.05, bp[2] + 0.04], 0.8, 0.4); }
        else if (id === 27) hearts(Q([GP[0], 1.6, GP[2]]), 4);
        else if (id === 28) {
          const bp: V3 = [hr[0] + 0.3, hr[1] + 0.3, hr[2] + 0.05]; bottle(bp, 0.5, "KETCHUP", "", false, 2.4);
          for (let i = 0; i < 4; i++) { const u = ((t - 47.5 - i * 0.22) % 0.9) / 0.5; if (t < 47.5 || u < 0 || u > 1) continue; fx("drop", 128, 128, dropDraw, [lerp(hr[0] + 0.12, hr[0] + 0.03, u), lerp(hr[1] + 0.2, hr[1] + 0.06, u * u), bp[2]], 0.07, 0.09); }
        }
      }
      break;
    }
    case "seventies": {
      const heinz = (expr: Expr) => put(out, cam, { who: C.heinz, p: Q(KU), t, expr, facing: 0 });
      if (id === 21) {
        const tm: [Who, number][] = [[C.nA, 0.4], [C.w2, 1.8], [C.w4, 3.2]];
        tm.forEach(([w, x], i) => { put(out, cam, { who: w, p: Q([x, PH + 0.16, FZ + 0.42]), t, expr: "grin", facing: i === 2 ? -1 : 1 }); fx("tomato", 256, 256, tomatoDraw, Q([x + (i === 2 ? -0.4 : 0.4), PH + 0.75, FZ + 0.6]), 0.3, 0.3); });
        hearts(Q([1.8, 2.4, FZ + 0.6]), 5);
      } else {
        const g = heinz(id === 24 ? "smug" : "smile");
        if (id === 22 || id === 23) { const an = anchorsOf(g), hr = toWorld(cam, g, an.r); bottle([hr[0], hr[1] + (id === 23 ? 0.3 : 0.12), hr[2] + 0.06], id === 23 ? 0.55 : 0.42); }
        if (id === 24) { fx("pill", 256, 256, pillDraw, Q([0.9, 1.2, -4.4]), 0.45, 0.45); fx("xmark", 256, 256, xDraw, Q([0.9, 1.2, -4.38]), 0.5, 0.5); }
      }
      break;
    }
  }
  return out;
};
void bodySide; void BX1; void SKIN; void smooth; void WW; void WH; void fxBurst; void zee; void tapAt; void walkX; void KU; void MARY; void zzz; void tapBurst; void D1;
export { FPS };
