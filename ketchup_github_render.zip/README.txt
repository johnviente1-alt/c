HOW TO RENDER ON GITHUB (free, no PC):
1. On github.com create a new repository (private is fine).
2. Upload everything in this folder (unzip first, then drag all files and folders into "Add file > Upload files").
   Make sure the hidden folder .github is included (it holds render.yml).
3. Open the Actions tab > "Render ketchup short" > Run workflow.
4. Wait about 25-40 minutes. Open the finished run, scroll to Artifacts, download ketchup_short_mp4 (inside is ketchup_short_1080p.mp4).
